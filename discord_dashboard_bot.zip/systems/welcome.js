module.exports = {
  name: 'welcome',
  execute(member) {
    console.log(`Welcome message placeholder for ${member.user.tag}`);
  }
};